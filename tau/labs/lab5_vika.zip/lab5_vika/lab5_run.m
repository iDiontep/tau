clc;

addpath("data");

Params; 

open('lab5.slx');
